/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package examen2;

/**
 *
 * @author invitado
 */
public class EmpleadoTiempoCompleto extends Empleado{
    public EmpleadoTiempoCompleto(String nombre, double salarioBase) {
        super(nombre, salarioBase);
    }
    
    
    
    @Override
    public double calcularSalarioAnual() {
        double salarioAnual = getSalarioBase() * 12;
        double bonus = salarioAnual * 0.1;
        return salarioAnual + bonus;
    }
}
